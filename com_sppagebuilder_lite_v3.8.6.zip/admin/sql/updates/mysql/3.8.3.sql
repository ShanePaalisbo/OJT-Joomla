-- 3.8.3
ALTER TABLE `#__sppagebuilder` MODIFY `catid` int(10) NOT NULL DEFAULT '0';
ALTER TABLE `#__sppagebuilder` MODIFY `ordering` int(11) NOT NULL DEFAULT '0';

